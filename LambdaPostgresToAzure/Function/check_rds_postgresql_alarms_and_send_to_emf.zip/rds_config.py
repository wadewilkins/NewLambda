#config file containing credentials for rds mysql instance
db_username = "wwilkins"
db_password = "wwilkins"
db_name = "wwilkins5"
db_endpoint = "wwilkins5.czkg5cms1vxp.us-west-2.rds.amazonaws.com"

db_errors_per_cycle=1
db_slow_log_per_cycle=1
db_dead_locks_per_cycle=0
db_select_latency_per_cycle=90
db_dml_latency_per_cycle=50
